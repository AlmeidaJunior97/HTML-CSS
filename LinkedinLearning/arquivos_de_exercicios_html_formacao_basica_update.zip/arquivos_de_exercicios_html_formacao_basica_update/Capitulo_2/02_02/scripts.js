function mostrarPreco(valor) {
  alert("O carro vale R$" + valor);
}